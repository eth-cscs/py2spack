# Example Python Package
For testing purposes.

Package is published at TestPyPI as [example-python-package-intern-pyspack](https://test.pypi.org/manage/project/example-python-package-intern-pyspack/releases/).

